import {showView} from "./util.js";

let section = document.querySelector('#form-sign-up');

export function registerPage() {
    showView(section);
}